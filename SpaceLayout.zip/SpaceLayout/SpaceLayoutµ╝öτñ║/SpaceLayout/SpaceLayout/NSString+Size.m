//
//  NSString+Size.m
//  BNproduct
//
//  Created by qianfeng on 16/9/21.
//  Copyright © 2016年 zjh. All rights reserved.
//

#import "NSString+Size.h"

@implementation NSString (Size)

//根据文字计算宽和高
- (CGSize)sizeWithFontSize:(CGFloat)fontSize maxSize:(CGSize)maxSize
{
    return [self boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:fontSize]} context:nil].size;
}

@end
