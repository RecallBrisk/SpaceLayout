//
//  ViewController.m
//  SpaceLayout
//
//  Created by zjh on 16/9/29.
//  Copyright © 2016年 zjh. All rights reserved.
//

#import "ViewController.h"
#import "CollectionViewCell.h"

//计算文字的高和宽
#import "NSString+Size.h"
//导入头文件
#import "CollectionViewSpaceLayout.h"
//设置cell和计算统一的字体
#define kCellFont 14


@interface ViewController () <UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>

@property (nonatomic,weak) UICollectionView *collectionView;

@property (nonatomic,strong) NSMutableArray *dataArrM;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self collectionView];
    
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataArrM.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CollectionViewCell" forIndexPath:indexPath];
    cell.textLabel.text = self.dataArrM[indexPath.item];
    cell.textLabel.font = [UIFont systemFontOfSize:kCellFont];
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.layer.cornerRadius = 3;
    cell.clipsToBounds = YES;
    
    return cell;
}

//必须实现
#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *title = self.dataArrM[indexPath.item];
    //文字的高和宽
    CGSize size = [title sizeWithFontSize:kCellFont maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    //根据文字高和宽在自己增加些范围，使之较为美观
    return CGSizeMake(size.width + 15, size.height + 10);
}

#pragma mark - 懒加载创建
- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        CollectionViewSpaceLayout *layout = [[CollectionViewSpaceLayout alloc] init];
        layout.sectionInsets = UIEdgeInsetsMake(8, 8, 8, 8);
        UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 20, self.view.frame.size.width, self.view.frame.size.height - 20) collectionViewLayout:layout];
        collectionView.delegate = self;
        collectionView.dataSource = self;
        
        collectionView.backgroundColor = [UIColor whiteColor];
        [collectionView registerNib:[UINib nibWithNibName:@"CollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"CollectionViewCell"];
        
        [self.view addSubview:collectionView];
        
        _collectionView = collectionView;
    }
    return _collectionView;
}

- (NSMutableArray *)dataArrM
{
    if (!_dataArrM) {
        _dataArrM = [NSMutableArray array];
        
        for (int i = 0; i < 60; i ++) {
            NSInteger num = arc4random()%3;
            NSString *str;
            if (num == 0) {
                str = @"搜索关键字";
            }else if(num == 1){
                str = @"关键词";
            }else if (num == 2){
                str = @"爱好";
            }else if (num == 3){
                str = @"编码风格";
            }
            [_dataArrM addObject:str];
        }
    }
    return _dataArrM;
}

@end
