//
//  CollectionViewCell.m
//  SpaceLayout
//
//  Created by zjh on 16/9/29.
//  Copyright © 2016年 zjh. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
