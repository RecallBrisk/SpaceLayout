//
//  NSString+Size.h
//  BNproduct
//
//  Created by qianfeng on 16/9/21.
//  Copyright © 2016年 zjh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (Size)

//根据文字计算宽和高
- (CGSize)sizeWithFontSize:(CGFloat)fontSize maxSize:(CGSize)maxSize;

@end
